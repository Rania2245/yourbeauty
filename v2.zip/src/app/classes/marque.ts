export class Marque {
  constructor(public nom: string) {}
}
