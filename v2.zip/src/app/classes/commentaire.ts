export class Commentaire {
  constructor(public id: number, public nom: string, public date: string) {}
}
