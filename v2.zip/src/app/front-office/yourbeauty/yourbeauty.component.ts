import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-yourbeauty',
  templateUrl: './yourbeauty.component.html',
  styleUrls: ['./yourbeauty.component.css']
})
export class YourbeautyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
